//package com.example.project_app.model;
//
//import com.example.project_app.network.NetworkCallback;
//
//public interface categoryRepository {
//
//}
