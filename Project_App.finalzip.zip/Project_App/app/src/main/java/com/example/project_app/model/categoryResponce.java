package com.example.project_app.model;

import java.util.List;

public class categoryResponce {
    List<Category> categories;

    public List<Category> getCategories() {
        return categories;
    }
}
