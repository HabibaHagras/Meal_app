package com.example.project_app.network;

public interface MealRemoteDataSource {
    void makeNetwokCall(NetworkCallback networkCallback);
    void makeNetwokCallCategory(NetworkCallback networkCallback);
}
