package com.example.project_app.randomMeal.view;

import com.example.project_app.model.Category;

import java.util.List;

public interface AllCategoryView {
    public void showdataCategory(List<Category> categories);

}
