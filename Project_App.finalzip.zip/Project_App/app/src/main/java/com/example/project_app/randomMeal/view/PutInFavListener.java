package com.example.project_app.randomMeal.view;


import com.example.project_app.model.Meal;

public interface PutInFavListener {
    void oPutInFavClick(Meal meal);
}
